<script>
  export let data;
</script>

<slot />
