<h2>Gallery</h2>
<form enctype="multipart/form-data">
  <input type="file" name="photo" />
  <button type="submit">Upload Photo</button>
</form>
