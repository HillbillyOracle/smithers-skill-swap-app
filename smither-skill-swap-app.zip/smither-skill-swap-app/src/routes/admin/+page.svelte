<h2>Admin Panel</h2>
<p>Protected CRUD interfaces go here.</p>
