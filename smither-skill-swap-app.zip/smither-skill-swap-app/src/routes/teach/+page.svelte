<h2>Teach a Skill</h2>
<form>
  <!-- instructor application fields -->
</form>
