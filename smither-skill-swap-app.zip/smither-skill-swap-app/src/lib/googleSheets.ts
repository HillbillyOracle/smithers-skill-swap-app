import { google } from 'googleapis';

const sheets = google.sheets('v4');

export async function appendToSheet(authClient, values) {
  await sheets.spreadsheets.values.append({
    auth: authClient,
    spreadsheetId: import.meta.env.VITE_GOOGLE_SHEETS_ID,
    range: 'Sheet1!A:C',
    valueInputOption: 'RAW',
    requestBody: { values: [values] }
  });
}
